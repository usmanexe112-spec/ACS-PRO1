const https = require("https");

// Helper: POST request returning parsed JSON
function httpPost(url, headers, body) {
  return new Promise((resolve, reject) => {
    const u = new URL(url);
    const options = {
      hostname: u.hostname,
      path: u.pathname + u.search,
      method: "POST",
      headers: { ...headers, "Content-Length": Buffer.byteLength(body) }
    };
    const req = https.request(options, (res) => {
      let data = "";
      res.on("data", (chunk) => (data += chunk));
      res.on("end", () => {
        try { resolve(JSON.parse(data)); }
        catch (e) { reject(new Error("Bad JSON from PhonePe: " + data.substring(0, 200))); }
      });
    });
    req.on("error", reject);
    req.write(body);
    req.end();
  });
}

module.exports = async function (req, res) {

  // CORS headers — allow GitHub Pages domain
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  res.setHeader("Content-Type", "application/json");

  // Preflight
  if (req.method === "OPTIONS") return res.status(200).end();
  if (req.method !== "POST")   return res.status(405).json({ success: false, error: "Method not allowed" });

  try {
    const { amount, name = "Customer", phone = "9999999999", email = "" } = req.body || {};

    const parsedAmount = parseFloat(amount);
    if (!parsedAmount || parsedAmount < 1) {
      return res.status(400).json({ success: false, error: "Enter a valid amount (minimum ₹1)." });
    }

    const CLIENT_ID     = process.env.PHONEPE_CLIENT_ID;
    const CLIENT_SECRET = process.env.PHONEPE_CLIENT_SECRET;
    const CLIENT_VER    = process.env.PHONEPE_CLIENT_VERSION || "1";

    if (!CLIENT_ID || !CLIENT_SECRET) {
      console.error("Missing PhonePe env vars");
      return res.status(500).json({ success: false, error: "Payment gateway not configured. Contact us on WhatsApp." });
    }

    // ── STEP 1: Get OAuth Token ─────────────────────────────────────────────
    const tokenBody = new URLSearchParams({
      client_id:      CLIENT_ID,
      client_version: CLIENT_VER,
      client_secret:  CLIENT_SECRET,
      grant_type:     "client_credentials"
    }).toString();

    let tokenData;
    try {
      tokenData = await httpPost(
        "https://api.phonepe.com/apis/identity-manager/v1/oauth/token",
        { "Content-Type": "application/x-www-form-urlencoded" },
        tokenBody
      );
    } catch (e) {
      console.error("Token fetch error:", e.message);
      return res.status(502).json({ success: false, error: "Could not reach PhonePe. Try again." });
    }

    if (!tokenData.access_token) {
      console.error("Token error response:", JSON.stringify(tokenData));
      return res.status(502).json({ success: false, error: "PhonePe auth failed. Try again.", detail: tokenData });
    }

    // ── STEP 2: Create Payment Order ────────────────────────────────────────
    const orderId     = "ACS" + Date.now() + Math.random().toString(36).substr(2, 4).toUpperCase();
    const siteBase    = process.env.SITE_URL || "https://affluentconsultancy.in";
    const redirectUrl = siteBase + "/payments/status/?orderId=" + orderId;

    const orderPayload = JSON.stringify({
      merchantOrderId: orderId,
      amount:          Math.round(parsedAmount * 100), // paise
      expireAfter:     1200,
      metaInfo:        { udf1: String(name), udf2: String(phone), udf3: String(email) },
      paymentFlow: {
        type:    "PG_CHECKOUT",
        message: "Payment for Affluent Consultancy Services",
        merchantUrls: { redirectUrl }
      }
    });

    let orderData;
    try {
      orderData = await httpPost(
        "https://api.phonepe.com/apis/pg/checkout/v2/pay",
        {
          "Content-Type":  "application/json",
          "Authorization": "O-Bearer " + tokenData.access_token
        },
        orderPayload
      );
    } catch (e) {
      console.error("Order fetch error:", e.message);
      return res.status(502).json({ success: false, error: "Could not create payment order. Try again." });
    }

    console.log("PhonePe order response:", JSON.stringify(orderData));

    if (orderData.redirectUrl) {
      return res.status(200).json({ success: true, redirectUrl: orderData.redirectUrl, orderId });
    }

    return res.status(502).json({ success: false, error: "PhonePe did not return a checkout URL.", detail: orderData });

  } catch (err) {
    console.error("Unhandled error:", err.message);
    return res.status(500).json({ success: false, error: "Server error: " + err.message });
  }
};
