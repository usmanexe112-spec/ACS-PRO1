# Affluent Consultancy Services

**Frontend:** GitHub Pages (static HTML/CSS/JS)
**Backend:** Vercel Serverless (PhonePe API)

---

## Setup Guide

### PART 1 — Deploy Backend on Vercel (do this FIRST)

1. Go to vercel.com → Sign up free with GitHub
2. Click Add New Project → Import your GitHub repo
3. Vercel auto-detects vercel.json → Click Deploy
4. After deploy, copy your project URL e.g. https://affluent-xyz.vercel.app

#### Add Environment Variables on Vercel:
Go to: Vercel → Project → Settings → Environment Variables

| Name | Value |
|------|-------|
| PHONEPE_CLIENT_ID | SU26052712194834440801383 |
| PHONEPE_CLIENT_SECRET | 00f6cf0e-d4a0-40b5-a5b6-45235fdee885 |
| PHONEPE_CLIENT_VERSION | 1 |

Click Save → go to Deployments → Redeploy

#### Update API URL:
Open payments/index.html → find this line:
  var VERCEL_API = "https://YOUR-PROJECT.vercel.app/api/payment";
Replace YOUR-PROJECT with your actual Vercel project name → save → push to GitHub.

---

### PART 2 — Deploy Frontend on GitHub Pages

1. Push all files to GitHub repo (main branch)
2. Go to: GitHub repo → Settings → Pages
3. Source: Deploy from a branch → Branch: main → Folder: / (root)
4. Click Save

#### Custom domain DNS (affluentconsultancy.in):
Add these A records in your domain registrar:
  185.199.108.153
  185.199.109.153
  185.199.110.153
  185.199.111.153
Add CNAME: www → YOUR-USERNAME.github.io
