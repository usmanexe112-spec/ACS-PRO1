// ============================================================
// ACTIVE NAV LINK
// ============================================================
function setActiveNav() {
  var path = window.location.pathname.replace(/\/+$/, '') || '/';
  document.querySelectorAll('.nav-links a').forEach(function(a) {
    var href = a.getAttribute('href').replace(/\/+$/, '') || '/';
    if (href === path) {
      a.classList.add('active');
    } else {
      a.classList.remove('active');
    }
  });
}

// ============================================================
// MOBILE MENU
// ============================================================
function toggleMobile() {
  var ham = document.getElementById('hamburger');
  var menu = document.getElementById('mobileMenu');
  ham.classList.toggle('open');
  menu.classList.toggle('open');
}

// ============================================================
// SCROLL ANIMATIONS
// ============================================================
function initAnimations() {
  var els = document.querySelectorAll('.fade-in');
  var observer = new IntersectionObserver(function(entries) {
    entries.forEach(function(entry, i) {
      if (entry.isIntersecting) {
        setTimeout(function() { entry.target.classList.add('visible'); }, i * 60);
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.08 });
  els.forEach(function(el) { observer.observe(el); });
}

// ============================================================
// COUNTERS
// ============================================================
function initCounters() {
  var counters = document.querySelectorAll('.counter');
  counters.forEach(function(counter) {
    var target = parseInt(counter.getAttribute('data-target'));
    var duration = 1800;
    var step = target / (duration / 16);
    var current = 0;
    var timer = setInterval(function() {
      current += step;
      if (current >= target) {
        current = target;
        clearInterval(timer);
      }
      counter.textContent = Math.floor(current) + '+';
    }, 16);
  });
}

// ============================================================
// CONTACT FORM VALIDATION
// ============================================================
function submitForm() {
  var valid = true;
  var name = document.getElementById('cf-name');
  var phone = document.getElementById('cf-phone');
  var email = document.getElementById('cf-email');
  var service = document.getElementById('cf-service');

  document.querySelectorAll('.form-error').forEach(function(e) { e.style.display = 'none'; });
  var successEl = document.getElementById('formSuccess');
  if (successEl) successEl.style.display = 'none';

  if (!name || !name.value.trim() || name.value.trim().length < 2) {
    var errName = document.getElementById('err-name');
    if (errName) errName.style.display = 'block';
    valid = false;
  }
  if (!phone || !phone.value.trim() || !/^[0-9+\s\-]{8,15}$/.test(phone.value.trim())) {
    var errPhone = document.getElementById('err-phone');
    if (errPhone) errPhone.style.display = 'block';
    valid = false;
  }
  if (email && (!email.value.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value.trim()))) {
    var errEmail = document.getElementById('err-email');
    if (errEmail) errEmail.style.display = 'block';
    valid = false;
  }
  if (!service || !service.value) {
    var errService = document.getElementById('err-service');
    if (errService) errService.style.display = 'block';
    valid = false;
  }

  if (valid) {
    var form = document.getElementById('contact-form');
    fetch('/contact', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams(new FormData(form)).toString(),
    })
    .then(function() {
      var succ = document.getElementById('formSuccess');
      if (succ) {
        succ.style.display = 'block';
        succ.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      }
      if (name) name.value = '';
      if (phone) phone.value = '';
      if (email) email.value = '';
      if (service) service.value = '';
      var msg = document.getElementById('cf-message');
      if (msg) msg.value = '';
      var budget = document.getElementById('cf-budget');
      if (budget) budget.value = '';
    })
    .catch(function() {
      alert('Sorry, there was an error sending your message. Please try again or contact us via WhatsApp.');
    });
  }
}

// ============================================================
// PAYMENT HANDLER
// ============================================================
function handlePayment() {
  alert('Payment gateway integration:\n\nPlease replace this with your payment button or order form.\n\nAlternatively, contact us via WhatsApp at +91 9348807611 to confirm payment details.');
}

// ============================================================
// NAVBAR SCROLL EFFECT
// ============================================================
window.addEventListener('scroll', function() {
  var navbar = document.getElementById('navbar');
  if (navbar) {
    if (window.scrollY > 60) {
      navbar.style.boxShadow = '0 4px 30px rgba(0,0,0,0.4)';
    } else {
      navbar.style.boxShadow = 'none';
    }
  }
});

// ============================================================
// INIT
// ============================================================
document.addEventListener('DOMContentLoaded', function() {
  setActiveNav();
  initAnimations();
  if (document.querySelectorAll('.counter').length > 0) {
    setTimeout(initCounters, 600);
  }
});
